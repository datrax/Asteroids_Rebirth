#include "simplexthree.h"

SimplexThree::SimplexThree(QVector<double> func, QVector<QVector<double> > equations,
                           QVector<int> indexes, QVector<double> rightSide,
                           int currxInd, int lastInd) :
    SimplexTable()
{
    funcVarsCount = rightSide.size();
    QVector< QVector<double> > eqs;
    eqs << (QVector<double>(func.size()+1)) << (QVector<double>(func.size()+1));
    (eqs[0])[currxInd] = 1;
    (eqs[1])[currxInd] = -1;
    eqs[1].last() = eqs[0].last() = 1;
    x[0] = (int)(rightSide.at(currxInd)) - rightSide.at(currxInd);
    x[1] = -(x[0]+1);
    for(int i=0; i < 2; ++i, Cib.clear()) {
        for(int col=0; col<func.size(); ++col)
            (eqs[i])[col] += ((i==0)?-1.0:1.0) * equations.at(currxInd).at(col);
        X = equations;
        BSols = rightSide;
        Cj = func;
        Cj << 0;
        for(int eq=0; eq<X.size(); ++eq) X[eq] << 0;
        BInd = indexes;
        foreach(int ind, BInd) Cib << Cj.at(ind);
        Cib << 0;
        BInd << (lastInd = Cj.size()+i-1);
        BSols << x[i];

        BRow = X.size();
        BCol = 0;

        for(int col = BCol+1; col < eqs.at(i).size(); ++col)
            if( (eqs.at(i).at(col) < eqs.at(i).at(BCol))
            && (eqs.at(i).at(col) != eqs.at(i).at(BCol))
            && fabs((eqs.at(i).at(col))) > eps ) BCol = col;

        X << eqs.at(i);
        printTable();
        Dj = eqs.at(i);
        funcToMinimize = false;
        if(!negDeltasGone()) dualSimplex();

        if(isSolutionExist()){
            result = 0;
            optPlan.clear();
            for(int ind=0; ind<funcVarsCount; ++ind){
                if(!BInd.contains(ind))
                    optPlan << 0;
                else {
                    optPlan << BSols.at(BInd.indexOf(ind));
                    result += func.at(ind) * optPlan.at(ind);
                }
            }
            solutionExist = true;
            printf("F = %.2f\n", result);
            bool optPlanIsReal = false;
            foreach(double x, optPlan){
                if((x != 0) && !(  fabs( ((int)x / x)-1 ) < eps  )){
                    optPlanIsReal = true;
                    break;
                }
            }
            if(optPlanIsReal){
                nextTable = new SimplexThree(Cj, X, BInd, BSols, i, lastInd);
                result = nextTable->getResult();
                optPlan = nextTable->getOptPlan();
            }
        }
        else{
            solutionExist = false;
            printf("No integer solution exists\n");
        }
    }
}

void SimplexThree::dualSimplex()
{
    double BElem = X.at(BRow).at(BCol);
    for(int col = 0; col < X.at(BRow).size(); ++col) (X[BRow])[col] /= BElem;
    BSols[BRow] /= BElem;
    for(int row = 0; row < X.size(); ++row){
        if(row == BRow) continue;
        double mult = X.at(row).at(BCol);
        BSols[row] += BSols.at(BRow) * (-mult);
        for(int col = 0; col < X.at(row).size(); ++col)
            (X[row])[col] += X.at(BRow).at(col) * (-mult);
    }
    BInd[BRow] = BCol;
    Dj = calcDelta();
    printTable();
}

void SimplexThree::printTable()
{
    for(int i = 0; i < 15; ++i) putchar(' ');
    foreach(double c, Cj) printf("%9.2f", c);
    printf("\n%5s %2s %7s", "Ci", "BV", "BS\n");
    for(int i = 0; i < X.size()-1; ++i){
        printf("%5.0f x%d %6.2f",Cib.at(i),BInd.at(i)+1,BSols.at(i));
        foreach(double el, X.at(i)) printf("%9.2f",el);
        putchar('\n');
    }
    for(int i=0; i<6; ++i) putchar(' ');
    printf("x%d %6.2f",BInd.last()+1, BSols.last());
    foreach(double el, X.at(X.size()-1)) printf("%9.2f",el);
    putchar('\n');
    if(!Dj.isEmpty()){
      for(int i = 0; i < 15; ++i) putchar(' ');
      foreach(double d, Dj) printf("%9.2f",d);
    }
    printf("\n\n");
}
