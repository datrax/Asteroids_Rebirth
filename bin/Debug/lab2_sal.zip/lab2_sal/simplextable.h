#ifndef SIMPLEXTABLE_H
#define SIMPLEXTABLE_H
#define M 100
#define eps 1e-6
#include <cmath>
#include <QDebug>
#include <QVector>

enum SignType
{
    lessThanOrEqual,
    greaterThanOrEqual,
    equal
};

class SimplexTable
{
public:
    SimplexTable(QVector <double> func, QVector< QVector<double> > equations,
                 QVector<SignType> signs, QVector<double> rightSide,
                 bool minimize = false);
    SimplexTable();

    QVector<double> calcDelta();
    void simplex();
    void findBaseElement();
    bool isSolutionExist();
    bool negDeltasGone();

    void printTable();
    void sortTable();

    QVector<double> getOptPlan(){ return optPlan; }
    QVector<int> getIndexes() { return BInd; };
    QVector<double> getFunc() { return Cj; }
    QVector< QVector<double> > getVectors() { return X; };
    double getResult() { return result; }
    
    bool funcToMinimize, solutionExist;
    QVector< QVector<double> > X;
    QVector<int> BInd, fakeIndexes;
    int BCol, BRow, funcVarsCount;
    QVector<double> Cib, Cj, BSols, ratio, Dj, optPlan;
    double result;
};

#endif // SIMPLEXTABLE_H
