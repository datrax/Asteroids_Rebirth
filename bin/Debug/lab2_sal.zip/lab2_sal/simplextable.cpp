#include "simplextable.h"
#include <QDebug>
#include <stdio.h>

SimplexTable::SimplexTable()
{
}

SimplexTable::SimplexTable(QVector<double> func, QVector< QVector<double> > equations,
                           QVector<SignType> signs, QVector<double> rightSide, bool minimize)
{
    funcToMinimize = minimize;
    funcVarsCount = func.size();
    for(int row=0; row<rightSide.size(); ++row)
        if(rightSide.at(row) < 0){
            rightSide[row] *= -1.0;
            for(int col = 0; col < equations.at(row).size(); ++col)
                (equations[row])[col] *= -1.0;
            switch(signs.at(row)) {
                case lessThanOrEqual:
                    signs[row] = greaterThanOrEqual;
                    break;
                case greaterThanOrEqual:
                    signs[row] = lessThanOrEqual;
                    break;
                case equal:
                    break;
            }
        }
    QList<int> positions;
    for(int pos=0; pos<equations.size(); ++pos) positions << pos;
    QMutableListIterator<int> iter(positions);
    while(iter.hasNext()){
        for(int eq; iter.hasNext();) {
            eq=iter.next();
            switch(signs.at(eq)){
                case lessThanOrEqual:
                    for(int _eq = 0; _eq<equations.size(); ++_eq){
                        if(_eq == eq) continue;
                        equations[_eq] << 0;
                    }
                    equations[eq] << 1.0;
                    func << 0;
                    iter.remove();
                    break;

                case greaterThanOrEqual:
                    for(int _eq = 0; _eq<equations.size(); ++_eq){
                        if(_eq == eq) continue;
                        equations[_eq] << 0;
                    }
                    equations[eq] << -1.0;
                    func << 0;
                    signs[eq] = equal;
                    break;

                case equal:
                    for(int _eq = 0; _eq<equations.size(); ++_eq){
                        if(_eq == eq) continue;
                        equations[_eq] << 0;
                    }
                    equations[eq] << 1.0;
                    func << (funcToMinimize? 1.0 : -1.0) * M;
                    iter.remove();
                    break;
            }
        }
        iter.toFront();
    }
    Cj = func;
    X = equations;
    foreach(QVector<double> coeff, X){
        int i = coeff.size()-1;
        for(; coeff.at(i) == 0; --i);
        BInd << i;
    }
    fakeIndexes = BInd;
    foreach(int ind, BInd) Cib << Cj.at(ind);
    BSols = rightSide;
    Dj = calcDelta();
    ratio.resize(Cib.size());
    findBaseElement();
    printTable();
    while(!negDeltasGone()) simplex();
    if(isSolutionExist()){
        result = 0;
        for(int i=0; i<funcVarsCount; ++i){
            if(!BInd.contains(i))
                optPlan << 0;
            else {
                optPlan << BSols.at(BInd.indexOf(i));
                result += func.at(i) * optPlan.at(i);
            }
        }
        printf("F = %.3f\n", result);
        for(int i = 0; i < optPlan.size(); ++i)
            printf("x%d = %.3f\n", i+1, optPlan.at(i));
        solutionExist = true;
        sortTable();
    }
    else {
        solutionExist = false;
        printf("No solutions\n");
    }
}

void SimplexTable::simplex()
{
    double BElem = X.at(BRow).at(BCol);
    for(int col = 0; col < X.at(BRow).size(); ++col) (X[BRow])[col] /= BElem;
    BSols[BRow] /= BElem;
    for(int row = 0; row < X.size(); ++row){
        if(row == BRow) continue;
        double mult = X.at(row).at(BCol);
        BSols[row] += BSols.at(BRow) * (-mult);
        for(int col = 0; col < X.at(row).size(); ++col)
            (X[row])[col] += X.at(BRow).at(col) * (-mult);
    }
    BInd[BRow] = BCol;
    Cib[BRow] = Cj.at(BCol);
    Dj = calcDelta();
    findBaseElement();
    printTable();
}

QVector<double> SimplexTable::calcDelta()
{
    QVector<double> delta;
    double sum = 0;
    for(int col = 0; col < Cj.size(); ++col, sum = 0){
        for(int row = 0; row < Cib.size(); ++row)
            sum += Cib.at(row) * X.at(row).at(col);
        delta << sum - Cj.at(col);
    }
    return delta;
}

void SimplexTable::findBaseElement()
{
    BCol = 0;
    int neg = funcToMinimize?(-1):1;
    foreach(double d, Dj){
        if(d==0) ++BCol;
        else break;
    }
    for(int col = BCol+1; col < Dj.size(); ++col)
        if( (neg * Dj.at(col) < neg * Dj.at(BCol)) && (Dj.at(col) != Dj.at(BCol)) ) BCol = col;
    
    for(int row = 0; row < X.size(); ++row){
        if(X.at(row).at(BCol) < 0)
            ratio[row] = -1.0;
        else ratio[row] = BSols.at(row) / X.at(row).at(BCol);
    }
    for(int row = 0; row < ratio.size(); ++row)
        if(ratio.at(row) >= 0){
            BRow = row;
            break;
        }
    if(BRow<X.size()-1){
        for(int row = BRow+1; row < X.size(); ++row)
            if((ratio.at(row) < ratio.at(BRow)) && (ratio.at(row) > 0)) BRow = row;
    }
}

void SimplexTable::printTable()
{
    for(int i = 0; i < 15; ++i) putchar(' ');
    foreach(double c, Cj) printf("%9.2f", c);
    printf("\n%5s %2s %7s", "Ci", "BV", "BS\n");
    for(int i = 0; i < X.size(); ++i){
        printf("%5.0f x%d %6.2f",Cib.at(i),BInd.at(i)+1,BSols.at(i));
        foreach(double el, X.at(i)) printf("%9.2f",el);
        putchar('\n');
    }
    for(int i = 0; i < 15; ++i) putchar(' ');
    foreach(double d, Dj) printf("%9.2f",d);
    printf("\n\n");
}

bool SimplexTable::negDeltasGone()
{
    int neg = funcToMinimize?(-1):1;
    foreach(double d, Dj) if(neg*d<0) return false;
    return true;
}

bool SimplexTable::isSolutionExist()
{
    int pos = 0;
    foreach(int ind, BInd) {
        ++pos;
        if(ind < funcVarsCount){
            if(BSols.at(ind) < 0) {
                foreach(double el, X.at(pos-1))
                    if(el > 0) return false;
                BSols[ind] *= -1.0;
            }
            continue;
        }
        else if(Cib.at(pos-1) != 0) return false;
    }
    return true;
}

void SimplexTable::sortTable()
{
    for(int i = 0; i < X.size()-1; ++i){
        if(BInd.at(i) > BInd.at(i+1)){
            std::swap(X[i], X[i+1]);
            std::swap(Cib[i], Cib[i+1]);
            std::swap(BInd[i], BInd[i+1]);
            std::swap(BSols[i], BSols[i+1]);
        }
    }
}
