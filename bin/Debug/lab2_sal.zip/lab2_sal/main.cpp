#include <QCoreApplication>
#include "lpp.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    QVector<double> func;
        QVector< QVector<double> > equations; QVector<double> rSide;
        QVector<SignType> signs;
        func << -1.0 << -1.0;
        equations << (QVector<double>() << 1.0 << -2.0); signs << lessThanOrEqual; rSide << 0;
        equations << (QVector<double>() << 1.0 << -1.0); signs << greaterThanOrEqual; rSide << -1.0;
        equations << (QVector<double>() << 1.0 << 0); signs << greaterThanOrEqual; rSide << 0.75;
        LPP problem(func, equations, signs, rSide);


    return a.exec();
}
