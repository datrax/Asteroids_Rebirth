#include "lpp.h"

LPP::LPP(QVector<double> func, QVector< QVector<double> > equations,
         QVector<SignType> signs, QVector<double> rightSide, bool minimize)
{
    simpTable = new SimplexTable(func, equations, signs, rightSide, minimize);
    bool optPlanIsReal = false;
    foreach(double x, simpTable->getOptPlan()){
        if(!((int)x==x)){
            optPlanIsReal = true;
            break;
        }
    }
    if(optPlanIsReal){
        simpThree = new SimplexThree(simpTable->Cj,simpTable->X,
                                     simpTable->BInd,simpTable->BSols);
        QVector<double> optPlan = simpThree->getOptPlan();
        printf("\n------------------\nF = %.2f\n", simpThree->getResult());
        for(int i = 0; i < func.size(); ++i)
            printf("x%d = %.2f\n", i+1, optPlan.at(i));
    }
}
