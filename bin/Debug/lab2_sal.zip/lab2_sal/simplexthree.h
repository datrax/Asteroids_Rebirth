#ifndef DUALSIMPLEX_H
#define DUALSIMPLEX_H
#include "simplextable.h"

class SimplexThree : public SimplexTable
{
public:
    SimplexThree(QVector <double> func, QVector< QVector<double> > equations,
                QVector<int> indexes, QVector<double> rightSide,
                 int currxInd = 0, int lastInd = 0);
    SimplexThree *nextTable;
    double x[2];
    void dualSimplex();
    void printTable();
};

#endif // DUALSIMPLEX_H
