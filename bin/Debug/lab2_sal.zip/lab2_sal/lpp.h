#ifndef LPP_H
#define LPP_H
#include "simplextable.h"
#include "simplexthree.h"

class LPP
{
public:
    LPP(QVector<double> func, QVector< QVector<double> > equations,
        QVector<SignType> signs, QVector<double> rightSide, bool minimize = false);
    SimplexTable *simpTable;
    SimplexThree *simpThree;
};

#endif // LPP_H
